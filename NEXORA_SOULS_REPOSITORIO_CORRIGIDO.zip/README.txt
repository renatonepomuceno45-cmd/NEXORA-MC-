NEXORA SOULS 1.1.0 — projeto-fonte completo inicial

INCLUÍDO
- Almas por eliminar mobs (recompensas configuráveis em config.yml).
- PvP: vencedor recebe 50% do saldo de almas da vítima; a vítima perde essa mesma quantia.
- Proteção anti-farm: mesma dupla vencedor/vítima tem intervalo configurável (padrão 300 segundos).
- /almas: consulta o próprio saldo.
- /almas dar <jogador> <quantidade>
- /almas retirar <jogador> <quantidade>
- /almas definir <jogador> <quantidade>
- /loja: menu com Construção, Combate, Mineração e Sobrevivência.
- Catálogo editável com preço, raridade, material, quantidade e encantamentos.
- Compras descontam almas e entregam o item ao jogador.
- Saldos salvos em plugins/NexoraSouls/balances.yml.

INSTALAÇÃO / COMPILAÇÃO
Este ZIP contém o código-fonte Maven; não contém um .jar compilado.
Requer Java 21 e Maven para compilar. Na pasta do projeto, execute:
  mvn clean package
O .jar será criado em target/nexora-souls-1.1.0.jar.
Envie esse .jar à pasta plugins do servidor Paper e reinicie o servidor.

VERSÃO
O pom.xml usa Paper API 1.21.4 e Java 21 como base de compilação. O painel mencionado anteriormente mostrou “26.3”; confirme com a hospedagem qual API/versão Paper real está em execução. Se for uma versão diferente, pode ser necessário ajustar a versão da dependência no pom.xml e api-version no plugin.yml antes de compilar/instalar.

BEDROCK
O plugin é instalado no servidor Paper e os jogadores Bedrock conectados por Geyser podem usar os mesmos dados e comandos. A interface usa inventários padrão; teste no Bedrock antes de abrir para todos.

IMPORTANTE
Faça backup do mundo e teste primeiro em um servidor de teste. Os saldos são persistidos, mas o cooldown anti-farm fica em memória e reinicia quando o servidor reinicia. O plugin não inclui RTP/TPA: esses comandos são recursos separados da hospedagem/plugins já existentes.
